@import 'utils.js'

function openExportLayersDialog(){
  var app = [NSApplication sharedApplication];
  var exportWindow = [[NSWindow alloc] init];
  var horizontalMargin = 35;
  var width = 565;
  var height = 385;

  COScript.currentCOScript().setShouldKeepAround_(true);
  [exportWindow setFrame:NSMakeRect(0, 0, width, height+20) display: false];

  var headerView = [[NSView alloc] initWithFrame:NSMakeRect(0, height-146, width, 146)];
  headerView.setWantsLayer(true);
  [headerView setBackgroundColor:NSColor.whiteColor()];
  [[exportWindow contentView] addSubview:headerView];

  var imageView = [[NSImageView alloc] initWithFrame: NSMakeRect(215, 84, 143, 39)];
  var file = sketchApp.resourceNamed("logo.png");
  var icon = NSImage.alloc().initByReferencingURL(file);
  [imageView setImage: icon];
  [headerView addSubview:imageView];

  var titleField = [[NSTextField alloc] initWithFrame:NSMakeRect(195, 38, 200, 25)];
  [titleField setEditable:false];
  [titleField setBordered:false];
  [titleField setDrawsBackground:false];
  [titleField setFont:[NSFont boldSystemFontOfSize:15]];
  [titleField setStringValue:"Export artboards layers"];
  [headerView addSubview:titleField];

  var subtitleField = [[NSTextField alloc] initWithFrame:NSMakeRect(65, 16, 450, 25)];
  [subtitleField setEditable:false];
  [subtitleField setBordered:false];
  [subtitleField setFont:[NSFont systemFontOfSize:13]];
  [subtitleField setTextColor:NSColor.colorWithGray(0.4)]
  [subtitleField setDrawsBackground:false];
  [subtitleField setStringValue:"Export complete artboards layer hierarchy to your Justinmind prototype."];
  [headerView addSubview:subtitleField];

  var deviceTypeLabel =[[NSTextField alloc] initWithFrame: NSMakeRect(105, 185, 300, 25)];
  [deviceTypeLabel setEditable:false];
  [deviceTypeLabel setBordered:false];
  [deviceTypeLabel setFont:[NSFont systemFontOfSize:13]];
  [deviceTypeLabel setDrawsBackground:false];
  [deviceTypeLabel setStringValue:"Choose a device for your prototype:"];
  [[exportWindow contentView] addSubview:deviceTypeLabel];

  var deviceTypeCombo = [[NSPopUpButton alloc] initWithFrame: NSMakeRect(105, 158, 210, 25)];
  deviceTypeCombo.addItemsWithTitles(deviceTypes);
  [deviceTypeCombo setFont:[NSFont systemFontOfSize:13]];
  [deviceTypeCombo selectItemAtIndex:0];
  var defaultDevice = getDefault("exportDevice",null);
  if(defaultDevice){
    var indexDevice = deviceTypes.indexOf(defaultDevice.trim());
    if(indexDevice>=0)
      [deviceTypeCombo selectItemAtIndex:indexDevice];
  }
  [[exportWindow contentView] addSubview:deviceTypeCombo];

  var orientationCombo = [[NSPopUpButton alloc] initWithFrame: NSMakeRect(325, 158, 120, 25)];
  [orientationCombo setEnabled: false];
  [orientationCombo setFont:[NSFont systemFontOfSize:13]];
  orientationCombo.addItemsWithTitles(orientation);
  [orientationCombo selectItemAtIndex:0];
  var defaultOrientation = getDefault("exportOrientation",null);
  if(defaultOrientation){
    var indexOrientation = orientation.indexOf(defaultOrientation.trim());
    if(indexOrientation>=0)
      [orientationCombo selectItemAtIndex:indexOrientation];
  }
  [[exportWindow contentView] addSubview:orientationCombo];

  [deviceTypeCombo setCOSJSTargetFunction:function(sender) {
    var projectIndex = [deviceTypeCombo indexOfSelectedItem];
    if(projectIndex == 0)
      [orientationCombo setEnabled: false];
    else
      [orientationCombo setEnabled: true];
  }];

  var exportTextLabel =[[NSButton alloc] initWithFrame: NSMakeRect(105, 116, 300, 25)];
  [exportTextLabel setButtonType:NSSwitchButton];
  [exportTextLabel setTitle:@"Export text layers as images"];
  [exportTextLabel setFont:[NSFont systemFontOfSize:13]];
  [[exportWindow contentView] addSubview:exportTextLabel];
  if(getDefault("exportTextAsImage",0)==1)
    [exportTextLabel setState:NSOnState];

  var export2x =[[NSButton alloc] initWithFrame: NSMakeRect(105, 85, 300, 25)];
  [export2x setButtonType:NSSwitchButton];
  [export2x setTitle:@"Export images to 2x"];
  [export2x setFont:[NSFont systemFontOfSize:13]];
  [[exportWindow contentView] addSubview:export2x];
  if(getDefault("export2x",0)==1)
    [export2x setState:NSOnState];

  // var exportSingleLayer =[[NSButton alloc] initWithFrame: NSMakeRect(horizontalMargin, 65, 375, 25)];
  // [exportSingleLayer setButtonType:NSSwitchButton];
  // [exportSingleLayer setTitle:@"Flatten groups starting with 'ic_'"];
  // [exportSingleLayer setFont:[NSFont systemFontOfSize:12]];
  // [[exportWindow contentView] addSubview:exportSingleLayer];
  // if(getDefault("exportSingleLayer",1)==1)
  //   [exportSingleLayer setState:NSOnState];

  var exportButton = [[NSButton alloc] initWithFrame:NSMakeRect(292, 8, 92, 30)],
  cancelButton = [[NSButton alloc] initWithFrame:NSMakeRect(185, 8, 92, 30)];
  [exportButton setEnabled: true];
  [exportButton setTitle:"Export"];
  [exportButton setBezelStyle:NSRoundedBezelStyle];
  [exportButton setAction:"callAction:"];
  [cancelButton setTitle:"Cancel"];
  [cancelButton setBezelStyle:NSRoundedBezelStyle];
  [cancelButton setAction:"callAction:"];

  var bottomActionsView = [[NSView alloc] initWithFrame:NSMakeRect(0, 0,width, 68)];
  [[exportWindow contentView] addSubview:bottomActionsView];
  var border = [[NSView alloc] initWithFrame:NSMakeRect(45, 67,width-90, 1)];
  [bottomActionsView addSubview:border];
  border.setWantsLayer(true);
  [border setBackgroundColor:NSColor.colorWithRed_green_blue_alpha(210/255, 210/255, 210/255, 1.0)];


  [exportButton setCOSJSTargetFunction:function(sender) {
    enableExportTextAsImage = [exportTextLabel state] == NSOnState;
    enableExportImage2X = [export2x state] == NSOnState;
    // enableExportGroupAsSingleLayer = [exportSingleLayer state] == NSOnState;
    selectedDeviceType = deviceTypes[[deviceTypeCombo indexOfSelectedItem]];
    selectedOrientation = orientation[[orientationCombo indexOfSelectedItem]];
    setDefault("exportDevice",selectedDeviceType);
    setDefault("exportOrientation",selectedOrientation);
    setDefault("exportTextAsImage",enableExportTextAsImage);
    setDefault("export2x",enableExportImage2X);
    setDefault("exportSingleLayer",enableExportGroupAsSingleLayer);
    [exportWindow orderOut:nil];
    [[app mainWindow] endSheet: exportWindow];
    [exportButton setCOSJSTargetFunction:undefined];
    [cancelButton setCOSJSTargetFunction:undefined];
    COScript.currentCOScript().setShouldKeepAround_(false);
    var jimFile = openSaveFileDialog();
    if(jimFile){
      openProgressDialog(jimFile);
    }
  }];

  [cancelButton setCOSJSTargetFunction:function(sender) {
    [exportWindow orderOut:nil];
    [[app mainWindow] endSheet: exportWindow];
    [exportButton setCOSJSTargetFunction:undefined];
    [cancelButton setCOSJSTargetFunction:undefined];
    COScript.currentCOScript().setShouldKeepAround_(false);
  }];
  [bottomActionsView addSubview:exportButton];
  [bottomActionsView addSubview:cancelButton];
  [exportWindow setDefaultButtonCell:[exportButton cell]];
  [[app mainWindow] beginSheet:exportWindow completionHandler:nil];
}


function openExportArtboardDialog(){
  var app = [NSApplication sharedApplication];
  var exportWindow = [[NSWindow alloc] init];
  var horizontalMargin = 35;
  var width = 565;
  var height = 355;

  COScript.currentCOScript().setShouldKeepAround_(true);
  [exportWindow setFrame:NSMakeRect(0, 0, width, height+20) display: false];

  var headerView = [[NSView alloc] initWithFrame:NSMakeRect(0, height-146, width, 146)];
  headerView.setWantsLayer(true);
  [headerView setBackgroundColor:NSColor.whiteColor()];
  [[exportWindow contentView] addSubview:headerView];

  var imageView = [[NSImageView alloc] initWithFrame: NSMakeRect(215, 84, 143, 39)];
  var file = sketchApp.resourceNamed("logo.png");
  var icon = NSImage.alloc().initByReferencingURL(file);
  [imageView setImage: icon];
  [headerView addSubview:imageView];

  var titleField = [[NSTextField alloc] initWithFrame:NSMakeRect(184, 38, 230, 25)];
  [titleField setEditable:false];
  [titleField setBordered:false];
  [titleField setDrawsBackground:false];
  [titleField setFont:[NSFont boldSystemFontOfSize:15]];
  [titleField setStringValue:"Export artboards as images"];
  [headerView addSubview:titleField];

  var subtitleField = [[NSTextField alloc] initWithFrame:NSMakeRect(75, 16, 450, 25)];
  [subtitleField setEditable:false];
  [subtitleField setBordered:false];
  [subtitleField setFont:[NSFont systemFontOfSize:13]];
  [subtitleField setTextColor:NSColor.colorWithGray(0.4)]
  [subtitleField setDrawsBackground:false];
  [subtitleField setStringValue:"Export artboards as single images on your Justinmind prototype."];
  [headerView addSubview:subtitleField];

  var deviceTypeLabel =[[NSTextField alloc] initWithFrame: NSMakeRect(105, 155, 300, 25)];
  [deviceTypeLabel setEditable:false];
  [deviceTypeLabel setBordered:false];
  [deviceTypeLabel setFont:[NSFont systemFontOfSize:13]];
  [deviceTypeLabel setDrawsBackground:false];
  [deviceTypeLabel setStringValue:"Choose a device for your prototype:"];
  [[exportWindow contentView] addSubview:deviceTypeLabel];

  var deviceTypeCombo = [[NSPopUpButton alloc] initWithFrame: NSMakeRect(105, 128, 210, 25)];
  deviceTypeCombo.addItemsWithTitles(deviceTypes);
  [deviceTypeCombo selectItemAtIndex:0];
  [deviceTypeCombo setFont:[NSFont systemFontOfSize:13]];
  var defaultDevice = getDefault("exportDevice",null);
  if(defaultDevice){
    var indexDevice = deviceTypes.indexOf(defaultDevice.trim());
    if(indexDevice>=0)
      [deviceTypeCombo selectItemAtIndex:indexDevice];
  }
  [[exportWindow contentView] addSubview:deviceTypeCombo];

  var orientationCombo = [[NSPopUpButton alloc] initWithFrame: NSMakeRect(325, 128, 120, 25)];
  [orientationCombo setEnabled: false];
  orientationCombo.addItemsWithTitles(orientation);
  [orientationCombo setFont:[NSFont systemFontOfSize:13]];
  [orientationCombo selectItemAtIndex:0];
  var defaultOrientation = getDefault("exportOrientation",null);
  if(defaultOrientation){
    var indexOrientation = orientation.indexOf(defaultOrientation.trim());
    if(indexOrientation>=0)
      [orientationCombo selectItemAtIndex:indexOrientation];
  }
  [[exportWindow contentView] addSubview:orientationCombo];

  [deviceTypeCombo setCOSJSTargetFunction:function(sender) {
    var projectIndex = [deviceTypeCombo indexOfSelectedItem];
    if(projectIndex == 0)
      [orientationCombo setEnabled: false];
    else
      [orientationCombo setEnabled: true];
  }];


  var export2x =[[NSButton alloc] initWithFrame: NSMakeRect(105, 85, 300, 25)];
  [export2x setButtonType:NSSwitchButton];
  [export2x setTitle:@"Export images to 2x"];
  [export2x setFont:[NSFont systemFontOfSize:13]];
  [[exportWindow contentView] addSubview:export2x];
  if(getDefault("export2x",0)==1)
    [export2x setState:NSOnState];

  var exportButton = [[NSButton alloc] initWithFrame:NSMakeRect(292, 8, 92, 30)],
  cancelButton = [[NSButton alloc] initWithFrame:NSMakeRect(185, 8, 92, 30)];
  [exportButton setEnabled: true];
  [exportButton setTitle:"Export"];
  [exportButton setBezelStyle:NSRoundedBezelStyle];
  [exportButton setAction:"callAction:"];
  [cancelButton setTitle:"Cancel"];
  [cancelButton setBezelStyle:NSRoundedBezelStyle];
  [cancelButton setAction:"callAction:"];

  var bottomActionsView = [[NSView alloc] initWithFrame:NSMakeRect(0, 0,width, 68)];
  [[exportWindow contentView] addSubview:bottomActionsView];
  var border = [[NSView alloc] initWithFrame:NSMakeRect(45, 67,width-90, 1)];
  [bottomActionsView addSubview:border];
  border.setWantsLayer(true);
  [border setBackgroundColor:NSColor.colorWithRed_green_blue_alpha(210/255, 210/255, 210/255, 1.0)];

  [exportButton setCOSJSTargetFunction:function(sender) {
    enableExportImage2X = [export2x state] == NSOnState;
    selectedDeviceType = deviceTypes[[deviceTypeCombo indexOfSelectedItem]];
    selectedOrientation = orientation[[orientationCombo indexOfSelectedItem]];
    setDefault("exportDevice",selectedDeviceType);
    setDefault("exportOrientation",selectedOrientation);
    setDefault("export2x",enableExportImage2X);
    [exportWindow orderOut:nil];
    [[app mainWindow] endSheet: exportWindow];
    [exportButton setCOSJSTargetFunction:undefined];
    [cancelButton setCOSJSTargetFunction:undefined];
    COScript.currentCOScript().setShouldKeepAround_(false);
    var jimFile = openSaveFileDialog();
    if(jimFile){
      openProgressDialog(jimFile);
    }
  }];

  [cancelButton setCOSJSTargetFunction:function(sender) {
    [exportWindow orderOut:nil];
    [[app mainWindow] endSheet: exportWindow];
    [exportButton setCOSJSTargetFunction:undefined];
    [cancelButton setCOSJSTargetFunction:undefined];
    COScript.currentCOScript().setShouldKeepAround_(false);
  }];
  [bottomActionsView addSubview:exportButton];
  [bottomActionsView addSubview:cancelButton];
  [exportWindow setDefaultButtonCell:[exportButton cell]];
  [[app mainWindow] beginSheet:exportWindow completionHandler:nil];
}

function openSaveFileDialog(){
  var jimFilename = nsDoc.displayName()+ ".vp";

  var panel = [NSSavePanel savePanel];
  var allowedTypes = NSArray.arrayWithObject("vp");

  panel.setAllowedFileTypes(allowedTypes);
  panel.setExtensionHidden(false);
  panel.setNameFieldStringValue(jimFilename);
  //
  var result = panel.runModal();
  if (result == 0) {
    return null;
  }
  return panel.URL().path();
}

function openProgressDialog(jimFile){
  COScript.currentCOScript().setShouldKeepAround_(true);
  var app = [NSApplication sharedApplication];
  var progressWindow = [[NSWindow alloc] init];
  [progressWindow setFrame:NSMakeRect(0, 0, 455, 190) display: false];
  var contentView = [progressWindow contentView];
  [progressWindow setBackgroundColor:NSColor.whiteColor()];


  var imageView = [[NSImageView alloc] initWithFrame: NSMakeRect(157, 106, 143, 39)];
  var file = sketchApp.resourceNamed("logo.png");
  var icon = NSImage.alloc().initByReferencingURL(file);
  [imageView setImage: icon];
  [contentView addSubview:imageView];

  var titleField = [[NSTextField alloc] initWithFrame:NSMakeRect(50, 66, 355, 20)];
  [titleField setAlignment:NSCenterTextAlignment];
  [titleField setEditable:false];
  [titleField setBordered:false];
  [titleField setDrawsBackground:false];
  [titleField setFont:[NSFont boldSystemFontOfSize:15]];
  [titleField setStringValue:"Exporting artboards to Justinmind"];
  [contentView addSubview:titleField];

  var subtitleField = [[NSTextField alloc] initWithFrame:NSMakeRect(50, 10, 355, 25)];
  [subtitleField setAlignment:NSCenterTextAlignment];
  [subtitleField setEditable:false];
  [subtitleField setBordered:false];
  [subtitleField setFont:[NSFont systemFontOfSize:11]];
  [subtitleField setTextColor:NSColor.colorWithGray(0.4)]
  [subtitleField setDrawsBackground:false];
  [subtitleField setStringValue:"Exporting artboards..."];

  [[progressWindow contentView] addSubview:subtitleField];

  var activityIndicator = [[NSProgressIndicator alloc]initWithFrame:NSMakeRect(75,38,305,20)];
  [activityIndicator setStyle:NSProgress​Indicator​Bar​Style];
  [activityIndicator startAnimation:nil];
  [[progressWindow contentView] addSubview:activityIndicator];

  var okButton = [[NSButton alloc] initWithFrame:NSMakeRect(178, 12, 100, 30)];
  [okButton setTitle:"Ok"];
  [okButton setBezelStyle:NSRoundedBezelStyle];
  [okButton setCOSJSTargetFunction:function(sender) {
    [progressWindow orderOut:nil];
    [[app mainWindow] endSheet: progressWindow];
    [okButton setCOSJSTargetFunction:undefined];
    COScript.currentCOScript().setShouldKeepAround_(false);
  }];
  [okButton setAction:"callAction:"];
  [okButton setHidden:true];

  [[progressWindow contentView] addSubview:okButton];

  [[app mainWindow] beginSheet:progressWindow completionHandler:nil];
  try{
    var callback = function updateProgressMessage(message){
       [subtitleField setStringValue:message];
       [subtitleField displayIfNeeded];
    }
    startExport(jimFile,callback);
    [titleField setStringValue:"Exported succesfully!"];
    [okButton setHidden:false];
    [activityIndicator setHidden:true];
    [subtitleField setHidden:true];
  } catch(e) {
    [titleField setStringValue:"Export failed!"];
    alert("Error",e);
    [okButton setHidden:false];
     [activityIndicator setHidden:true];
    [subtitleField setHidden:true];
  }
}
